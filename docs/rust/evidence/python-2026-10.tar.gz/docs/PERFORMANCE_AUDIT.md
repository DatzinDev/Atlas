# Auditoría de rendimiento y arquitectura de Atlas

Fecha: 19 de octubre de 2026. Base inspeccionada: `7b53a1cfce370a61e6c5a6271190245e2d78db3c` (v0.1.0).

Seguimiento: [primera línea base medida](PERFORMANCE_BASELINE.md). Esta auditoría conserva
el alcance de la inspección inicial; las mediciones posteriores se documentan por separado.
La implementación y las mediciones de la primera optimización están en
[PERFORMANCE_OPTIMIZATION.md](PERFORMANCE_OPTIMIZATION.md); los flujos siguientes describen
la base anterior a esos cambios.
El backlog posterior de consultas, MVT y ráster opcional está en
[ISSUE_ROADMAP.md](ISSUE_ROADMAP.md), con enlaces a issues atómicos y sus dependencias.

## 1. Alcance y conclusión

Atlas es una **librería dentro de una aplicación FastAPI**, no un servidor independiente. Su arquitectura ya tiene decisiones favorables: pool asíncrono, filtros parametrizados compatibles con índices espaciales, reproyección en PostGIS, WKB para WMS, cursor de servidor para WFS/descargas y renderizado en un thread pool. No hace falta rediseñarla para empezar a mejorarla.

La primera optimización candidata es reducir las superficies de imagen que Pillow asigna y compone por geometría. En WFS, el conteo exacto previo y la serialización por feature merecen medición independiente. Antes de aumentar workers, hay que presupuestar memoria de imágenes y conexiones: más concurrencia puede empeorar ambos recursos.

**No hay una comparación de rendimiento comprobada contra GeoServer en esta auditoría.** No se ejecutaron peticiones, perfiles, SQL ni pruebas de carga. Se inspeccionaron código, tests, configuración, documentación y fuentes oficiales. El Python del entorno no tiene Atlas, pytest, Shapely ni psycopg instalados; no se instalaron dependencias ni se arrancaron servicios. Las pruebas citadas se leyeron, no se ejecutaron. No se modificó código de aplicación. El directorio preexistente y no rastreado `examples/web_viewer/` queda fuera del diagnóstico y no se alteró.

Clasificación usada:

- **C — Comprobado por inspección:** comportamiento visible en código; no implica que su impacto temporal esté medido.
- **R — Riesgo potencial:** el comportamiento existe, pero su impacto depende del tamaño de datos, configuración o concurrencia.
- **H — Hipótesis:** una alternativa podría mejorar el sistema; exige benchmark antes de adoptarla.

Carga de referencia propuesta, no demanda confirmada: tablas de 10 mil a 1 millón de features, geometrías de complejidad variable y concurrencia de 1 a 32 solicitudes. No se atribuyen a producción cifras de latencia, capacidad o memoria que no se hayan medido.

## 2. Arquitectura y flujos reales

| Componente | Responsabilidad y comportamiento actual |
|---|---|
| `integration.py:Atlas` | Construye `AtlasContext`, registro y routers. `startup` abre el pool; `shutdown` lo cierra; `lifespan` garantiza el cierre. La aplicación host elige servidor y workers. |
| `layers/metadata.py:build_layer` | Introspección y extent al registrar una capa; metadatos quedan en el registro del proceso. No se repite introspección por GetMap/GetFeature. |
| `postgis/connection.py:Database` | `AsyncConnectionPool`, filas como diccionarios, `statement_timeout`, consultas completas o cursor nombrado con lectura por lotes. |
| `postgis/queries.py` | SQL con identificadores seguros y valores enlazados; BBOX en CRS nativo; geometría de salida transformada por PostGIS. |
| `wms/` y `rendering/` | Validación, autorización por capa, selección WKB, Shapely, Pillow y respuesta PNG/JPEG. Renderer sustituible mediante `MapRenderer`. |
| `wfs/` | Una capa por petición, filtros, selección de atributos, conteo exacto, página con `LIMIT/OFFSET` y GeoJSON en streaming. |
| `exports/` y `api/download.py` | GeoJSON/CSV por filas; GPKG/SHP construidos en archivos temporales antes de enviarse. |

Rutas relativas a `src/atlas/` en esta tabla. El resto de referencias usa rutas desde la raíz del repositorio.

### WMS GetMap

```text
wms/router.py:build_router
  → GetMapParams (incluye orden de ejes WMS 1.3.0)
  → get_map: validar dimensiones, resolver capas y autorizar
  → por cada capa, secuencialmente:
      bbox_predicate: geom && envelope transformado al SRID nativo
      build_feature_query: PK + ST_AsBinary(ST_Transform(geom, destino)), LIMIT
      Database.fetch_all → lista WKB → shapely.wkb.loads en el event loop
  → retener todas las listas de geometrías
  → run_in_threadpool(renderer.render)
      validar geometría → coordenadas a píxeles → componer → reescalar → codificar
  → Response con imagen completa
```

`api/maps.py:export_map` comparte `get_map`; una mejora allí alcanza también la exportación de mapas. `wms/feature_info.py:get_feature_info` usa candidatos por BBOX más `ST_Intersects`, límite por capa y, por defecto, atributos sin geometría.

### WFS GetFeature

```text
wfs/router.py:build_router → _OperationResponse
  → validar KVP/form, capa, permisos, filtros, CRS y paginación
  → get_feature: SELECT count(*) con todos los filtros
  → SELECT atributos + ST_AsGeoJSON(ST_Transform(geom, destino))::json
       LIMIT página OFFSET inicio, sin ORDER BY
  → Database.stream: cursor de servidor, itersize=1000
  → precargar primera fila y serializarla antes de enviar headers
  → jsonable_encoder + json.dumps por feature → StreamingResponse
  → metadatos numberMatched/numberReturned → cerrar cursor
```

El conteo y la página usan adquisiciones separadas del pool. El cursor de la página mantiene su conexión y transacción mientras se consume la respuesta. `_FeatureResponse` y el generador cierran el cursor incluso en desconexiones, con protección frente a cancelación. `_OperationResponse` mantiene el registro de operación durante el envío completo; no confundir ese tiempo con CPU ni con duración SQL.

### Despliegue existente

`compose.yaml` solo define PostGIS `16-3.4`, volumen persistente, seed y healthcheck. No contiene servicio Atlas, Dockerfile, workers ASGI, proxy, cuotas o política de reinicio de aplicación. `.env.example` es desarrollo. `examples/spike.py` es una prueba descartable que abre conexiones por petición y renderiza dentro de endpoints async: **no representa el comportamiento del núcleo actual ni debe usarse como baseline de producción**.

`pyproject.toml` establece versiones mínimas, sin lockfile rastreado ni Uvicorn como dependencia del núcleo. Es coherente con ser una librería; la aplicación host debe fijar su entorno desplegado. La CI usa Python 3.11 y PostGIS con un seed diminuto: cinco polígonos, cuatro líneas y cinco puntos. Prueba comportamiento, no escala.

## 3. Hallazgos y recomendaciones fundamentadas

### F1. Composición de imágenes completas por geometría — C/R, prioridad P1

**Evidencia.** `src/atlas/rendering/pillow.py:_draw` (líneas 33–76) crea un overlay RGBA del tamaño completo por primitiva; un polígono añade una máscara L y un relleno RGBA, y se compone relleno y borde por separado. Un punto compone relleno y borde con dos overlays. `PillowRenderer.render` (79–111) usa supersampling 2 y recorre todas las geometrías y partes. También comprueba validez del multiparte y después la de cada parte.

**Problema.** Además del trabajo por vértice, hay asignaciones y composición proporcional al área de imagen por primitiva: aproximadamente `O(G × W × H × s² + V)`, con G primitivas, V vértices y s supersampling. Los temporales se reutilizan/liberan con el avance, no se retienen G imágenes simultáneamente; sí hay tráfico de memoria repetido. Una imagen de 4096² con s=2 tiene un lienzo RGBA de **256 MiB**. Lienzo + overlay + relleno + máscara de un polígono suman aproximadamente **832 MiB de buffers nominales**, sin contar temporales internos, geometrías, codificador y asignador. Es aritmética del código, no RSS medido.

**Mejora.** Perfilar `_draw` y probar overlays/máscaras limitados a la región afectada, incluyendo margen de borde y antialiasing. Componer cada feature en su orden; no agrupar indiscriminadamente polígonos transparentes en una sola máscara, porque cambia la superposición. Evitar superficies innecesarias en casos opacos solo cuando los tests demuestren equivalencia. Mantener el renderer existente y su interfaz.

**Medición y coste.** B1/B3: CPU, tiempo de render, RSS y pendiente al duplicar G y área. Validar huecos, orden de capas, opacidad, líneas y símbolos en bordes con `tests/rendering/test_pillow.py` y nuevas referencias visuales. Recortar regiones añade lógica geométrica en píxeles; hay que justificarla con perfiles. Bajar `supersample` a 1 ya es posible por inyección del renderer, pero pierde calidad: sirve como experimento separado, no como mejora equivalente.

### F2. Los límites actuales no garantizan un mapa completo ni memoria acotada — C/R, P0

**Evidencia.** `src/atlas/postgis/queries.py:fetch_render_geometries` (143–175) aplica `resolve_limit(None)`. `src/atlas/wms/get_map.py:get_map` (84–126) no especifica otro límite y conserva cada capa. `src/atlas/core/config.py:AtlasConfig` tiene `default_limit=1000`, `max_limit=10000`, `max_image_size=4096`. `GetMapParams` exige capas únicas pero no un máximo de capas.

**Problema.** Con 1,001 geometrías candidatas se seleccionan como máximo 1,000 sin advertencia de truncamiento. El límite cuenta filas, no vértices, partes ni bytes; una sola geometría puede ser enorme. Con L capas crecen geometrías retenidas y consultas; las dimensiones acotan cada imagen, no las imágenes simultáneas. Un mapa incompleto puede parecer competitivo en velocidad sin prestar el mismo servicio.

**Mejora.** Como primer paso, elegir en el host dimensiones y concurrencia compatibles con la memoria disponible y documentar el límite visual. Para una corrección posterior, detectar exceso con un candidato adicional y responder un error explícito compatible con el contrato OGC definido, o seleccionar representaciones generalizadas completas por escala. No elevar a ciegas `default_limit`, que también afecta WFS; no introducir muestreo silencioso ni omitir geometrías como optimización.

**Medición y coste.** B1/B3 con exactamente 999/1000/1001 candidatos, multipartes y L=1/4/8. Verificar cobertura e IDs esperados independientemente de la imagen. Registrar memoria máxima y resultado al exceder capacidad. Rechazar una solicitud es una política de capacidad, no equivalencia con un GetMap completo; esa limitación debe quedar visible en la comparación.

### F3. WFS cuenta todo antes de emitir una página — C/R, P1

**Evidencia.** `src/atlas/wfs/get_feature.py:get_feature` (77–100), `src/atlas/postgis/queries.py:count_query` (135–140). `COUNT(*)` no tiene el límite de la página. En descarga, `src/atlas/api/download.py:download` solo cuenta cuando `max_download_features` está configurado.

**Problema.** Una página de 10 features puede esperar el conteo de un millón de coincidencias. El streaming reduce memoria de la página, no ese trabajo previo. Conteo y página pueden observar estados distintos si hay escrituras entre consultas.

**Mejora.** Medir primero el conteo y sus planes. Mantener exactitud por defecto; un caché de conteos solo es exacto con invalidación/versionado de datos y filtros. Evaluar una representación de total desconocido únicamente tras verificar estándar y contrato de clientes, como cambio público separado; no sustituir el total por el tamaño de página ni por estadísticas aproximadas presentadas como exactas. Para el techo de descargas, probar una subconsulta acotada a `cap+1` para detectar exceso sin contar todo; no sirve para el total WFS.

**Medición y coste.** B2: tiempo de conteo frente a primera fila y descarga completa, con selectividad 0/0.1/10/100 %. Probar escrituras concurrentes si se exige consistencia entre total y página. Cachear introduce invalidación; una única transacción con snapshot estable puede dar consistencia, pero mantiene más tiempo recursos y no elimina el conteo.

### F4. OFFSET profundo y ausencia de orden estable — C/R, P1

**Evidencia.** `src/atlas/postgis/queries.py:build_feature_query` (121–132) añade `LIMIT/OFFSET` sin `ORDER BY`. `src/atlas/wfs/pagination.py:resolve_pagination` valida/capa count, pero acepta índices de inicio grandes.

**Problema.** Páginas consecutivas no tienen orden garantizado; cambios de plan pueden repetir u omitir features incluso sin cambios de datos. Un offset grande obliga al servidor a procesar filas descartadas. PostgreSQL documenta ambos efectos en [LIMIT/OFFSET](https://www.postgresql.org/docs/current/queries-limit.html).

**Mejora.** Definir orden determinista con PK única cuando exista. Para vistas sin PK, exigir una clave estable declarada o documentar que no puede garantizarse paginación estable; no ordenar por una columna arbitraria no única. Conservar `startIndex` WFS. Si el recorrido secuencial masivo lo exige, usar la descarga existente; paginación por cursor sería una extensión separada, nunca sustitución silenciosa de `startIndex`.

**Medición y coste.** B2 con offsets 0/10 mil/100 mil/900 mil, validando IDs sin repeticiones en un dataset congelado. Comparar planes con orden: puede añadir sort o cambiar un buen plan espacial. La estabilidad entre páginas bajo escrituras requiere además una política de snapshot, no basta el ORDER BY.

### F5. Se preserva el índice espacial, pero faltan planes reales — C/H, P1

**Evidencia.** `src/atlas/postgis/queries.py:bbox_predicate` (50–58) transforma la ventana, no la columna indexada. El seed crea GiST sobre cada `geom`. `fetch_render_geometries` selecciona WKB sin atributos extra salvo PK. `build_feature_query` transforma la salida incluso si SRID destino y origen son iguales. WFS y WMS usan `&&`; solo GetFeatureInfo añade intersección exacta.

**Problema.** No hay evidencia de que las tablas reales tengan índices adecuados ni estadísticas recientes. Geometrías grandes o dispersas producen muchos candidatos por caja; vistas complejas pueden dominar la consulta. `LIKE '%texto%'` y filtros poco selectivos pueden requerir scans. No todo scan secuencial es malo: puede ser óptimo en una ventana que cubre casi todo.

**Mejora.** Verificar GiST, estadísticas y planes en las tablas base; añadir índices de atributos solo para filtros frecuentes que los planes justifiquen. Conservar identificadores/valores seguros. Probar omitir `ST_Transform` cuando los SRID son iguales. Medir `&&` frente a `&& + ST_Intersects` para mapas con muchos falsos candidatos, sin cambiar la semántica WFS de forma inadvertida. La exactitud del filtro BBOX debe revisarse contra el subconjunto OGC declarado antes de llamarla optimización.

**Medición y coste.** B1/B2 y `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)` con los SQL y parámetros generados realmente, incluyendo consulta por cursor. Registrar candidatos, filas, buffers, planificación y ejecución. Más índices cuestan almacenamiento y escrituras; la intersección exacta añade CPU. No recomendar índices funcionales sobre toda reproyección si la consulta actual ya filtra la columna nativa.

### F6. Geometrías completas y trabajo síncrono antes del renderer — C/R/H, P2

**Evidencia.** `src/atlas/postgis/queries.py:fetch_render_geometries` materializa WKB y llama a `loads(bytes(...))` por fila dentro de una función async. `src/atlas/rendering/pillow.py:_draw` valida y convierte coordenadas una a una. No hay simplificación ni recorte en SQL. `get_map` sí envía `renderer.render` a `run_in_threadpool`: sería incorrecto afirmar que todo WMS bloquea el loop.

**Mejora.** Si B3 muestra pausas, trasladar la decodificación por lote a un hilo con capacidad limitada y probar la operación vectorizada `shapely.from_wkb` ya disponible en la dependencia actual. No crear una tarea por feature. Evaluar simplificación **solo para render** en PostGIS, tras el filtro nativo, con tolerancia proporcional al tamaño de píxel en CRS de salida; evaluar recorte con margen para símbolos y bordes. No simplificar WFS/descargas ni reparar geometrías silenciosamente.

**Medición y coste.** B1/B3: bytes WKB, vértices, tiempo SQL/decodificación/render y retraso del event loop. La [simplificación que preserva topología](https://postgis.net/docs/ST_SimplifyPreserveTopology.html) conserva topología de cada geometría, pero no bordes compartidos entre polígonos. Verificar huecos y continuidad; no prometer equivalencia visual sin comparación. Añade CPU a PostGIS y puede perder detalle; la opción solo procede si reduce el coste total.

### F7. GeoJSON se decodifica y vuelve a recorrer/serializar — C/H, P2

**Evidencia.** `build_feature_query` devuelve `ST_AsGeoJSON(...)::json`; el driver lo convierte a objetos Python. `src/atlas/wfs/get_feature.py:encode` (91–96) hace `to_geojson_feature → jsonable_encoder → json.dumps`; el generador emite una feature por chunk. Esto preserva tipos especiales de atributos, pero vuelve a recorrer coordenadas. No se materializa la colección entera.

**Mejora.** Empezar con `propertyName` y `geometry=false`, que ya existen, cuando el consumidor solo necesita atributos. Probar buffers de salida por bytes (p. ej., 32–64 KiB) para reducir envíos ASGI, conservando primera emisión rápida y memoria acotada. Si el perfil confirma coste de conversión, comparar geometría JSON textual insertada sin decodificación o features serializadas en SQL; mantener escape, nulos, Unicode, fechas, decimales e IDs. No usar `json_agg` de toda la colección ni añadir un serializador nuevo sin beneficio medido.

**Medición y coste.** B2/B3: CPU por feature/vértice, bytes, chunks, TTFB y finalización. Bufferizar añade latencia y complica errores parciales; SQL JSON completo desplaza CPU a la base y puede cambiar tipos. Comparar objetos parseados, no solo tamaño de respuesta; conservar `allow_nan=False` y límites.

### F8. Clientes lentos retienen conexiones y los timeouts no cubren toda la petición — C/R, P0

**Evidencia.** `src/atlas/postgis/connection.py:Database.stream` mantiene el bloque `connection()` durante cada yield. WFS usa lotes de 1000; descargas usan 16. `Database.open` no establece `timeout` ni `max_waiting` propios del pool. `query_timeout=30` configura `statement_timeout`, no tiempo de render, espera de pool ni tiempo total de streaming. `max_download_features=None` permite descarga sin límite de filas.

**Problema.** Diez clientes lentos pueden ocupar las diez conexiones máximas de un worker y retrasar mapas/consultas de la misma app. Un cursor de servidor acota buffers, no duración total, transacción ni presión sobre mantenimiento de PostgreSQL. El timeout SQL no garantiza cerrar una respuesta en 30 segundos.

**Mejora.** Aplicar admisión y duración máxima de solicitudes/descargas en el host; conservar cierre de generadores y cancelación. Definir espera de pool y cola máxima si las métricas muestran saturación, con traducción de errores adecuada. Elegir tamaño de lote por bytes/latencia de red y tamaño de geometrías; no imponer 1000 a todas las descargas. Una conexión separada para tareas pesadas solo se justifica si la contención persiste tras límites, y debe entrar en el mismo presupuesto PostgreSQL.

**Medición y coste.** B4: consumidores limitados en velocidad, desconexión antes de headers y a mitad del cuerpo, agotamiento del pool, conexiones/cola y transacciones activas tras cancelar. La [documentación del pool](https://www.psycopg.org/psycopg3/docs/api/pool.html) diferencia espera y cola; verificar defaults de la versión desplegada. Limitar o rechazar reduce capacidad aparente, pero evita una cola sin control. No eliminar la limpieza existente, cubierta por `tests/wfs/test_get_feature.py` y `tests/api/test_download.py`.

### F9. Exportadores de archivo hacen I/O síncrono en funciones async — C/R, P1

**Evidencia.** `src/atlas/exports/geopackage.py:GeoPackageExporter.export` y `src/atlas/exports/shapefile.py:ShapefileExporter.export` llaman a Fiona `target.write` por fila, operaciones de disco y, en SHP, ZIP síncrono. `api/download.py` consume el primer chunk antes de enviar headers para exportadores no streaming; construir el archivo sucede antes de la primera respuesta. `CSVExporter.export` convierte GeoJSON a Shapely para WKT/centroide; incluso CSV `geometry=none` solicita actualmente GeoJSON en SQL.

**Mejora.** Primero acotar descargas, concurrencia y disco temporal. Probar escritura Fiona por lotes acotados y ejecución de trabajo síncrono en un hilo dedicado con cola limitada, manteniendo acceso exclusivo al handle y cierre ante cancelación. No pasar el iterador async directamente a una función síncrona ni introducir una tarea por fila. Para CSV sin geometría, omitirla en consulta; para WKT/centroide, comparar cálculo SQL respetando CRS y semántica actuales.

**Medición y coste.** B4 con tráfico WMS/WFS simultáneo: p95 de solicitudes pequeñas, lag del loop, filas/s, I/O y espacio temporal máximo. Cancelación debe borrar archivos. Fiona/GDAL nativo no implica ausencia de bloqueo del loop; un hilo añade coordinación y no se justifica por una prueba de cinco filas.

### F10. Pool de hilos, workers y consultas multicapa necesitan un presupuesto conjunto — C/R/H, P1

**Evidencia.** `get_map` consulta capas secuencialmente y usa el pool de hilos compartido de Starlette. `src/atlas/layers/permissions.py:check_permission` ejecuta el checker síncrono directamente y espera el asíncrono; `visible_layers` los recorre en serie. `src/atlas/core/logging.py:log_operation` invoca el hook síncrono en el loop.

**Mejora.** Mantener checkers síncronos solo si son rápidos y locales; usar async para I/O de autorización y hooks que entreguen a logging no bloqueante del host. No abrir una cola sin límite. Medir 1/2/4 workers antes de aumentar hilos; usar un límite de renders simultáneos acorde a RAM. Solo probar consultas paralelas por capa con concurrencia pequeña si la latencia SQL multicapa domina; conservar el orden de dibujo y cancelar/limpiar todas las consultas al fallar una.

**Medición y coste.** B3/B4: CPU por núcleo, lag del loop, espera de hilos/pool y RSS total. Más workers multiplican pools, registro, caché y memoria base. Más hilos no garantizan escalar el código Python por el GIL ni las bibliotecas nativas; hay que medir. Starlette documenta un [limitador compartido de 40 tokens por defecto](https://starlette.dev/threadpool/); no es un objetivo de renders paralelos ni una configuración específica de Atlas.

### F11. Cada GetMap repetido rehace consulta y dibujo — C/H, P2

**Evidencia.** No hay caché de imágenes/geometrías en `get_map` ni implementación WMTS. El registro de capas sí reutiliza metadatos. `src/atlas/wms/router.py` acepta BBOX arbitrario; no existe validación de una cuadrícula de tiles.

**Mejora.** Medir repetición real. Para capas públicas poco cambiantes, comenzar por caché HTTP en el proxy existente, con TTL explícito, o una caché de bytes limitada por memoria en el host. Para caché dentro del flujo, autorizar antes de resolver el hit. La clave debe incluir operación/versión, capas **en orden**, CRS y BBOX normalizados respetando ejes, dimensiones, formato, transparencia, fondo, estilo efectivo, versión de datos y contexto de permisos. No compartir respuestas privadas solo por URL ni convertir un permiso revocado en un hit válido. No cachear fallos.

**Medición y coste.** B5: hit/miss, latencia, CPU, RAM y frescura tras cambiar datos/estilo/permisos. TTL permite obsolescencia: pactar su tolerancia; si se requiere exactitud, usar versión explícita de publicación. Una caché por worker multiplica almacenamiento y duplica misses; acotar entradas, bytes y solicitudes idénticas en vuelo. No añadir Redis: primero demostrar que la duplicación entre procesos es el cuello real.

Tiles con BBOX exacto y dimensiones constantes favorecen reutilización, pero no deben redondearse solicitudes WMS arbitrarias al tile más cercano. WMTS es otra capacidad y queda fuera de esta fase. La [integración GeoWebCache de GeoServer](https://docs.geoserver.org/stable/en/user/geowebcache/using/) debe declararse al comparar: render sin caché y tile caliente son escenarios diferentes.

### F12. Registro de capas y extents pueden encarecer arranques y réplicas — C/R, P2

**Evidencia.** `src/atlas/postgis/introspection.py:table_extent` intenta estimación para tablas; para vistas/materializadas (`is_view`) o si no hay estimación útil termina en `ST_Extent(ST_Transform(...))`. `build_layer` lo ejecuta salvo override explícito de extent. El registro está en memoria del proceso.

**Mejora.** Mantener estadísticas y pasar un extent conocido mediante el override existente cuando sea válido. Registrar las mismas capas al arrancar cada worker; no abrir el pool en un proceso padre y compartirlo. Si se necesita registro dinámico, distribuir su configuración desde el mecanismo de despliegue existente; añadir réplicas sin eso puede producir catálogos inconsistentes.

**Medición y coste.** B6: tiempo de startup por capa, consultas/CPU de PostGIS al iniciar 1/2/4 workers y readiness. El extent estático necesita actualizarse cuando cambia la cobertura. No presentar este trabajo como coste de cada petición: sucede al registrar.

## 4. Optimizaciones ordenadas

Impacto = beneficio potencial para el escenario señalado, no aceleración medida. Esfuerzo bajo: configuración/cambio localizado; medio: varias rutas y pruebas; alto: nueva implementación o contrato. P0: condición previa a producción/comparación válida; P1: primer ciclo medido; P2: después de perfilar; P3: solo ante evidencia persistente.

| Acción | Evidencia | Impacto esperado | Esfuerzo | Prioridad | Validación |
|---|---|---|---|---|---|
| Controlar dimensiones, admisión, duración y presupuesto RAM/conexiones | F2/F8 | Alto, estabilidad bajo carga | Bajo–medio | P0 | B3/B4, sin OOM y recuperación |
| Detectar/documentar truncamiento WMS; fijar equivalencia del benchmark | F2 | Alto, corrección | Bajo diagnóstico; medio corrección | P0 | 999/1000/1001 y cobertura |
| Reducir superficies de composición por feature | F1 | Alto en mapas densos/grandes | Medio | P1 | B1, mismos píxeles/semántica |
| Verificar GiST, estadísticas y filtros frecuentes | F5 | Alto si faltan o hay malos planes | Bajo–medio | P1 | EXPLAIN y buffers |
| Separar conteo del coste de página; optimizar detección del cap de descarga | F3 | Alto con muchos matches | Bajo medir; medio cambiar | P1 | B2, totales exactos |
| Orden estable WFS sin eliminar startIndex | F4 | Alto en corrección; rendimiento variable | Medio | P1 | IDs y planes por offset |
| Sacar escritura/ZIP pesado del loop, por lotes | F9 | Alto con exportación concurrente | Medio | P1 | B4, lag y limpieza |
| Ajustar workers, hilos y pool con carga mixta | F10 | Alto si hay contención | Bajo–medio | P1 | B3/B4, RSS agregado |
| Omitir geometría en CSV none y usar proyección de atributos existente | F7/F9 | Medio–alto en geometrías grandes | Bajo | P1 | B2, igualdad de columnas |
| Evitar ST_Transform identidad | F5 | Bajo–medio, por comprobar | Bajo | P2 | Tiempo SQL y CRS iguales |
| Vectorizar/aislar decodificación WKB | F6 | Medio si domina decodificación | Bajo–medio | P2 | B3, lag/CPU |
| Bufferizar GeoJSON y evitar recorrido redundante | F7 | Medio en WFS grande | Medio | P2 | B2, TTFB y tipos iguales |
| Caché pública acotada de imágenes | F11 | Alto solo con repetición | Medio | P2 | B5, hit y frescura |
| Simplificar/recortar solo representación WMS | F6 | Alto en geometrías complejas | Medio | P2 | B1, detalle y bordes |
| Extents conocidos y registro consistente por worker | F12 | Medio en arranque con muchas vistas | Bajo | P2 | B6 |
| Consultar capas en paralelo con límite | F10 | Medio si domina I/O multicapa | Medio | P2 | B3, DB y RAM sin regresión |
| Renderer nativo alternativo detrás de MapRenderer | F1/F6 | Desconocido hasta perfilar | Alto | P3 | Mismos datos/estilos/calidad |

PostGIS, GEOS/Shapely, Pillow y Fiona/GDAL ya aportan código nativo. Mapnik solo se justificaría si, tras reducir trabajo redundante, el render sigue dominando el objetivo incumplido. Debe evaluarse el coste binario y operativo del [ADR 0002](adr/0002-renderer-pillow-sobre-mapnik.md); no exige cambiar el lenguaje ni el resto de la arquitectura.

## 5. Recomendaciones de producción

### Proceso ASGI y recursos

La aplicación host debe usar lifespan con cierre garantizado y registro de capas en cada worker. El ejemplo inicial del README solo muestra startup; para producción reutilizar `Atlas.lifespan` o un lifespan del host que invoque startup/shutdown en `try/finally`. Readiness debe confirmar pool abierto y capas registradas, sin calcular extents ni ejecutar mapas en cada sondeo.

Empezar con un worker para línea base y medir 2/4 si hay CPU y RAM. No usar `--reload` en producción. Uvicorn ofrece workers y límites de concurrencia; los límites globales también afectan rutas ajenas a Atlas si comparten app. Las opciones dependen del servidor elegido por el host: verificar la [configuración oficial de Uvicorn](https://uvicorn.dev/settings/) y su versión fijada, sin añadir Gunicorn por defecto.

Presupuestos a calcular con mediciones:

```text
Conexiones máximas Atlas = réplicas × workers × pool_max_size
                          (+ otras instancias Atlas y conexiones del host)
RAM requerida ≈ workers × RAM base
              + renders simultáneos totales × incremento RSS pico por render
              + buffers WFS/exportación/caché + margen del asignador
```

Por ejemplo, 4 workers con los defaults permiten hasta 40 conexiones, no 10. Reservar conexiones para administración y otras aplicaciones. No asignar todo `max_connections` a Atlas ni asumir que todos los renders consumen la misma RAM. Si PostgreSQL comparte máquina, reservarle CPU/RAM fuera del límite del contenedor de aplicación.

Configurar límites de duración total y velocidad/tiempo de lectura de clientes según servicio esperado, además de `statement_timeout`. El keep-alive ASGI no sustituye un timeout de petición activa. Una desconexión no garantiza que un render nativo que ya corre en un hilo se detenga; verificar y mantener la admisión limitada hasta liberar el recurso real.

### Contenedor y dependencias

El Compose actual es de desarrollo: publica PostGIS sin limitarlo a loopback y usa credenciales conocidas por defecto. En producción usar red privada o binding restringido, secretos del host, rol de base con permisos mínimos de lectura, backups y almacenamiento persistente. No copiar ese Compose como despliegue listo.

La imagen de la aplicación host debe fijar Python y resolución completa de paquetes probada (lock/constraints del host), arrancar sin privilegios, manejar SIGTERM y tener tiempo de apagado compatible con cancelación/limpieza. Definir CPU, memoria y espacio temporal. Con `[export]`, verificar wheels/Fiona/GDAL y formatos disponibles durante build; omitir ese extra si no se usan GPKG/SHP. No se propone instalar nuevas dependencias en el núcleo.

El disco temporal puede superar el archivo final: SHP retiene componentes y ZIP simultáneamente; GPKG se construye completo antes de enviar. Si `/tmp` es tmpfs, su uso cuenta contra RAM. Dimensionarlo y limitar exportaciones concurrentes según B4.

### Escalabilidad y observabilidad

Escalar verticalmente primero si render/CPU domina y PostgreSQL tiene margen; aumentar procesos bajo presupuesto de RAM. Añadir réplicas solo cuando la capacidad de una instancia sea insuficiente y verificar registro/configuración iguales, conexiones agregadas e invalidación de cachés locales. No hay necesidad demostrada de microservicios, Kubernetes ni caché distribuida.

Registrar TTFB y duración hasta último byte por operación, estado y desconexión; métricas de pool, render, CPU, RSS del proceso/contenedor, disco temporal y lag del loop. Evitar BBOX, URL, principal e IDs de features como etiquetas métricas de alta cardinalidad. `OperationLog` es un punto existente para logs, pero no separa etapas. Añadir tiempos ligeros solo donde los benchmarks requieran atribución. El hook no debe escribir a red/disco de forma bloqueante. WMS mide construcción antes de devolver Response; WFS incluye envío mediante `_OperationResponse`; las métricas actuales no son directamente comparables.

## 6. Benchmarks reproducibles propuestos

Estos pasos son una especificación para la siguiente fase; **no se ejecutaron ni se agregaron scripts al repositorio**. Ejecutar SQL generador y carga únicamente contra una base aislada de benchmark. No usar la base de producción ni sobrescribir el seed de pruebas.

### Preparación y trazabilidad

1. Guardar commit, cambios locales, OS/kernel, CPU/cuota, RAM/límite, disco, Python, paquetes resueltos, PostGIS/GEOS/PROJ, servidor ASGI y argumentos. Registrar número de workers, pool, supersampling y límites; ocultar credenciales. Usar el mismo entorno resuelto en antes/después.
2. Montar un host mínimo que use **la librería actual**, no el spike ni el viewer local. En lifespan: abrir Atlas, registrar `bench.points`, `bench.lines`, `bench.polygons`, cerrar en finally. Exponer `geo.router`; conservar esa app y configuración como artefacto del benchmark posterior. La versión inicial debe usar defaults, y otra variante explícita debe permitir probar conjuntos WMS completos sin truncamiento.
3. Crear un corpus determinista y guardar SQL, conteos, extensión, suma/distribución de `ST_NPoints`, bytes de geometría, atributos e índices. Congelar datos durante cada comparación y hacer `ANALYZE` tras cargar. Conservar un corpus real anonimizado adicional con polígonos grandes, huecos, multipartes y distribución sesgada.
4. Usar tamaños de 10 mil/100 mil/1 millón de puntos; variar complejidad de polígonos/líneas sin multiplicar de entrada todos los casos. El seed de 14 features es solo control funcional.

Generación inicial determinista, en **base aislada**, sin aleatoriedad ni extensiones nuevas:

```sql
CREATE SCHEMA bench;
CREATE TABLE bench.points AS
SELECT i::bigint AS id, (i % 100)::integer AS category,
       ('feature-' || i)::text AS name,
       ST_SetSRID(ST_MakePoint(
           -103.0 + ((i - 1) % 1000) * 0.001,
            20.0 + ((i - 1) / 1000) * 0.001), 4326)::geometry(Point,4326) AS geom
FROM generate_series(1, 1000000) AS s(i);
ALTER TABLE bench.points ADD PRIMARY KEY (id);
CREATE INDEX points_geom_idx ON bench.points USING gist (geom);
CREATE INDEX points_category_idx ON bench.points (category);
ANALYZE bench.points;
```

Derivar subconjuntos por ID para las otras escalas. Para polígonos, generar en CRS métrico con `ST_Buffer` y `quad_segs` fijo (8/64/256) sobre una cuadrícula determinista; transformar una copia a 4326. Para líneas, `ST_MakeLine` de secuencias ordenadas por índice con 10/100/1000 vértices. Guardar el SQL exacto final, hashes y tamaños; no llamar reproducible a un corpus descrito solo como «polígonos complejos».

### Peticiones base

Ejemplos ejecutables una vez preparado el host anterior. `curl` mide headers iniciales y descarga completa; no sustituye una carga concurrente:

```bash
curl --fail --silent --show-error --get http://127.0.0.1:8000/atlas/wms \
  --data-urlencode SERVICE=WMS --data-urlencode VERSION=1.3.0 \
  --data-urlencode REQUEST=GetMap --data-urlencode LAYERS=points \
  --data-urlencode CRS=EPSG:4326 --data-urlencode BBOX=20,-103,20.01,-102.99 \
  --data-urlencode WIDTH=256 --data-urlencode HEIGHT=256 \
  --data-urlencode FORMAT=image/png --output /tmp/atlas-bench-map.png \
  --write-out 'status=%{http_code} ttfb=%{time_starttransfer} total=%{time_total} bytes=%{size_download}\n'

curl --fail --silent --show-error --get http://127.0.0.1:8000/atlas/wfs \
  --data-urlencode SERVICE=WFS --data-urlencode VERSION=2.0.0 \
  --data-urlencode REQUEST=GetFeature --data-urlencode TYPENAMES=points \
  --data-urlencode COUNT=1000 --data-urlencode STARTINDEX=0 \
  --data-urlencode SRSNAME=EPSG:4326 --output /tmp/atlas-bench-features.json \
  --write-out 'status=%{http_code} ttfb=%{time_starttransfer} total=%{time_total} bytes=%{size_download}\n'
```

En WMS EPSG:4326 el BBOX está en latitud/longitud; no copiar el mismo orden a CRS:84, EPSG:3857 ni al SQL nativo. Registrar el nombre de publicación real si el host lo sobrescribe. Verificar contenido y dimensiones, no aceptar solo HTTP 200 como resultado correcto.

### Matriz mínima

| ID | Experimento | Variables y evidencia que debe producir |
|---|---|---|
| B1 | SQL y render WMS aislados | Separar SQL, WKB decode, dibujo, resize y PNG/JPEG. 100/500/1000 primitivas, 256²/1024² y 4096² solo con memoria suficiente; s=2 baseline, s=1 como calidad distinta. Medir geometrías/partes/vértices y RSS por proceso. |
| B2 | WFS y serialización | COUNT 10/1000/10000; total matches 0/0.1/10/100 %; offsets 0/10k/100k/900k; todas/pocas propiedades; geometry true/false; CRS igual/distinto. Separar COUNT, primera fila y emisión completa. |
| B3 | Concurrencia | C=1/2/4/8/16/32, workers 1/2/4 con presupuesto constante de máquina. Mapas pequeños/grandes y mezcla 70 % WMS, 25 % WFS, 5 % descargas como escenario inicial explícito. Reportar por operación, no solo promedio global. |
| B4 | Recursos y fallos | Consumidores rápidos y limitados a 64 KiB/s, cancelación, SQL que excede timeout en entorno aislado, pool ocupado, exportaciones GPKG/SHP/CSV y disco acotado. Observar recuperación de conexiones, archivos y latencia de peticiones pequeñas. |
| B5 | Caché y navegación | Una vista repetida, recorrido de 100 BBOX exactos y BBOX aleatorios. Probar caché vacía/caliente/desactivada, actualizaciones e invalidación. Medir hit ratio, bytes guardados y coste de misses simultáneos. |
| B6 | Arranque | Registro de 1/10/100 capas, tablas con estadísticas y vistas con extent exacto/override. Medir readiness, consultas y coste de arrancar workers simultáneamente. |

Para SQL guardar `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)` del conteo y selección con los parámetros exactos. Una selección ejecutada directamente y una mediante cursor pueden tener planes distintos: capturar el caso real, no inferirlo solo del SELECT independiente. No sumar tiempos de EXPLAIN como si incluyeran conversión del driver o transferencia HTTP.

### Ejecución y análisis

- Usar un generador de carga con conexiones persistentes (herramienta externa al núcleo, versión fijada). Separar generación y servidor si compiten por CPU; medir también CPU del generador. Guardar URLs, headers, cuerpos y distribución de solicitudes, sin credenciales.
- Por caso: 30 segundos de calentamiento, 120 segundos medidos y 5 repeticiones independientes. Mantener mismos datos, cuota y red. Con pocas muestras no reportar p99 como estable; ampliar duración. Alternar el orden de variantes para reducir sesgos térmicos/caché.
- Carga cerrada por concurrencia para localizar saturación; después carga a tasa fija creciente, registrando retraso de envío, cola y solicitudes descartadas. No ocultar saturación porque los clientes ralentizan su emisión. Guardar latencias individuales para p50/p95/p99 y dispersión entre repeticiones.
- Reportar solicitudes/s **correctas**, errores por código, timeouts, TTFB, último byte, bytes/s, CPU, RSS/PSS agregados, pico de memoria de contenedor, conexiones/espera del pool, lag del loop y espacio temporal. En WFS validar JSON completo y número de features: un stream truncado después de headers no es éxito.
- Separar caché de aplicación, buffers PostgreSQL/OS y, para GeoServer, calentamiento de JVM. «Primer proceso» no equivale a disco frío. Solo reiniciar/vaciar cachés del sistema en máquina aislada y describir exactamente el procedimiento.
- Aceptación propuesta: mejora de al menos 15 % en p95 o CPU por respuesta en el escenario objetivo, superior a la variabilidad observada, sin regresión significativa en memoria, errores ni calidad. Es un criterio propuesto, no un SLO confirmado. Fijar después un SLO real y límite de capacidad con el equipo.

### Comparación justa con GeoServer

Usar la misma instantánea PostGIS, índices, filtros, CRS, ventana, dimensiones, atributos, cantidad de features y estilos equivalentes. Asignar el mismo presupuesto de CPU y memoria total; registrar heap JVM, pools y workers. Ejecutar servidores por separado para que no compitan accidentalmente por la base. Incluir memoria base y tiempo de arranque: son parte de la ventaja buscada de Atlas.

Publicar por separado: (a) render dinámico sin caché de imagen en ambos; (b) repetición con caché equivalente; (c) navegación de BBOX variable. No enfrentar GeoWebCache caliente con Atlas sin caché ni un Atlas truncado a 1000 con un mapa GeoServer completo. Una configuración GeoServer que presta capacidades extra no demuestra coste de esas capacidades si el benchmark no las solicita.

WFS debe compararse en el subconjunto común realmente implementado: GeoJSON de lectura, una capa y filtros admitidos. El README y [ADR 0003](adr/0003-alcance-ogc-reducido.md) declaran alcance OGC reducido; no se afirma conformidad completa. Mantener ejes WMS 1.3.0, reproyección, autorización, límites explícitos, totales y tipos de atributos. Para imágenes, comprobar cobertura y tolerancias visuales acordadas; distintos motores no tienen por qué producir hashes idénticos.

### Pruebas de regresión que acompañarían futuras mejoras

Reutilizar `tests/postgis/test_render_query.py`, `test_bbox.py`, `test_queries.py`; `tests/rendering/test_pillow.py`; `tests/wms/test_get_map.py`, `test_feature_info.py`, `test_router.py`; `tests/wfs/test_get_feature.py`, `test_router.py`; `tests/api/test_download.py`, `test_maps.py` y `tests/exports/`. Añadir casos de gran cardinalidad/complejidad solo donde prueben una regresión concreta: truncamiento, orden, memoria, cancelación, tipos o composición.

La suite requiere `ATLAS_TEST_DATABASE_URL`; `tests/conftest.py` omite pruebas sin esa variable y puede omitir componentes no importables. Un «pytest verde» con skips no valida PostGIS ni rendimiento. Registrar pasadas/omitidas y motivos, además de versiones. Las pruebas vía HTTPX ASGI son funcionales; no sustituyen socket real, workers y clientes lentos.

## 7. Roadmap incremental y decisiones de avance

1. **Línea base y capacidad segura (P0).** Preparar host y corpus aislados; registrar límites, verificar truncamiento, presupuestar RAM/conexiones y medir B1–B4. Resultado: informe antes/después reproducible y techo inicial de solicitudes. Sin modificar todavía el renderer.
2. **Cambios locales baratos (P1/P2).** Verificar índices/estadísticas; omitir geometría para CSV none; probar identidad de CRS; aplicar proyección de atributos existente; ajustar configuración ASGI/pool bajo carga. Un cambio por experimento, con tipos y resultados iguales. Ordenar WFS con clave estable como corrección independiente.
3. **Eliminar trabajo dominante (P1).** Si F1 domina, reducir superficies de Pillow con pruebas visuales. Si domina la base, actuar sobre planes/conteo. Si el lag aparece durante exportaciones, aislar escritura por lotes. No ejecutar tres refactors a la vez: deben poder atribuirse mejora y regresión.
4. **Optimizar representación y repetición (P2).** Simplificación WMS y caché pública acotada únicamente cuando B1/B5 las justifiquen. Evaluar buffers JSON y WKB vectorizado si el perfil los sitúa entre los mayores costes. Mantener una ruta sin caché y una representación sin simplificación para validar.
5. **Escalar o sustituir renderer (P3).** Repetir B3/B4, aumentar workers/réplicas dentro del presupuesto. Evaluar renderer alternativo solo si el SLO sigue incumplido y render es el límite demostrado. Documentar coste de instalación, memoria y mantenimiento antes de decidir.

Cada fase entrega datos crudos, configuración exacta, validación funcional y una decisión de conservar/revertir. No se promete superar a GeoServer sin esas mediciones. La oportunidad inmediata es hacer menos trabajo por solicitud y controlar recursos, conservando el servicio que recibe el usuario.
