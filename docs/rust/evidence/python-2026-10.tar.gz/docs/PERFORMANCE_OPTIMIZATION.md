# Primera optimización de rendimiento

Fecha: 19 de octubre de 2026. Cambios locales sobre `7b53a1c`, sin nuevas dependencias
ni servicios de producción. Continúa la [auditoría](PERFORMANCE_AUDIT.md) y la
[línea base histórica](PERFORMANCE_BASELINE.md). No se implementan protocolos adicionales.

## Cambios realizados

| Problema comprobado | Implementación | Verificación |
|---|---|---|
| Pillow asignaba y componía imágenes completas por primitiva | `rendering/pillow.py:_draw` limita overlays, máscaras y rellenos a sus bounds en píxeles, ampliados por radio/borde | Comparación exacta de píxeles con la implementación anterior para huecos, transparencias, trazos fraccionarios y objetos fuera del viewport, a 1× y 2×; suite gráfica existente |
| GetMap repetía SQL, decodificación y dibujo para peticiones idénticas | `wms/cache.py:MapCache`, LRU local de bytes; integración en `wms/get_map.py:get_map` | HIT evita consultar; pruebas de TTL, bytes, entradas, reemplazo, permisos, estilos e invalidación; benchmark separado con caché desactivada/activa |
| WMS aplicaba el límite WFS de 1.000 sin informar de pérdida de cobertura | `postgis/queries.py:fetch_render_geometries`, presupuesto independiente y compartido entre capas; una fila adicional detecta exceso | 1.001 geometrías en prueba con `default_limit=1`; ventana HTTP de 100.000 puntos comprobada mediante conteo del hook; exceso produce `QueryTooLarge` |
| Más peticiones retenían listas y ejecutaban dibujos a la vez | `AtlasContext.render_slots`, adquirido antes de consultar y liberado al terminar; si se cancela un dibujo, espera al hilo nativo antes de liberar | Máximo dos operaciones activas con cinco solicitudes, cancelación durante consulta y cancelaciones repetidas durante dibujo; cierre del cursor al exceder presupuesto |

Se conservan geometrías completas, orden de capas, alfa, supersampling, PNG/JPEG, ejes WMS
1.3.0 y reproyección en PostGIS. No se introduce simplificación ni muestreo. La selección por
BBOX y el comportamiento previo de saltar geometrías inválidas/vacías siguen vigentes.

### Política de caché

- 32 MiB de imágenes y hasta 256 entradas por instancia, TTL 30 segundos desde inserción.
  Los accesos no renuevan TTL. El tamaño cuenta payload; hay overhead adicional de Python.
- Solo mapas de capas públicas sin principal ni permission checker, con `PillowRenderer`.
  Con autenticación/checker o renderer externo se informa `BYPASS`. No se cachean errores.
- La clave incluye parámetros normalizados, configuración y orden de capas, estilos efectivos,
  supersampling, presupuestos y generación de invalidación. Los permisos se revisan antes de usarla.
- `Atlas.invalidate_cache()` después del commit de datos descarta imágenes. Registro de capas,
  startup y shutdown invalidan automáticamente. Un render antiguo no repuebla una generación nueva.
- Cada worker posee su caché: invalidar una instancia no invalida las demás. Para publicación
  inmediata, el host debe notificar a cada instancia o desactivar caché. Escrituras externas
  no detectadas pueden dejar visible la imagen anterior durante el TTL, más el tiempo de un
  render ya iniciado. No es una garantía transaccional de frescura.
- `X-Atlas-Cache: HIT|MISS|BYPASS` permite observar el uso. `Cache-Control: no-store` conserva
  el control de autorización/frescura en Atlas, sin cachés HTTP externas implícitas.
- No es WMTS/GWC: no hay gridsets, seeding, persistencia ni reutilización parcial entre BBOX
  distintos. Un frontend con ventanas repetibles/tiles WMS aprovecha mejor esta caché.
- El semáforo y la segunda consulta de caché reducen trabajo en espera; dos misses idénticos
  pueden renderizar simultáneamente. No se promete deduplicación completa.

No se cachean indiscriminadamente WFS, conteos o geometrías: respuestas grandes multiplicarían
RAM y un conteo antiguo podría contradecir la página actual. Los metadatos de capas ya se
conservan en el registro. La siguiente caché debe justificarse por frecuencia, tamaño y frescura.

## Resultados del piloto HTTP

Misma máquina de la línea base: Ryzen 5 7640HS, Python 3.13.11, paquetes restaurados desde su
snapshot, Uvicorn de un worker y PostGIS temporal limitado a 1 CPU/512 MiB. Se reinició el
worker entre la prueba sin caché y la prueba con caché. No hay aislamiento de carga del sistema.
Los JSON registran fuentes, paquetes y configuración efectiva; el commit por sí solo no
identifica las modificaciones locales.

Cada corrida tiene 240 respuestas medidas: diez casos × concurrencias 1/4 × doce muestras,
con una petición de calentamiento por combinación. Ambas finalizaron sin errores. El p95
con doce muestras equivale al máximo; este piloto no estima capacidad de producción.

Mediana en ms, concurrencia 1:

| WMS | Línea base | Optimizado sin caché | Caché caliente |
|---|---:|---:|---:|
| Puntos 256² | 1.386,9 | 47,1 | 1,11 |
| Puntos 1024² | 15.507,2 | 161,2 | 2,06 |
| Líneas 256² | 160,3 | 36,9 | 1,22 |
| Líneas 1024² | 4.277,1 | 169,8 | 1,88 |
| Polígonos 256² | 485,1 | 163,7 | 1,22 |
| Polígonos 1024² | 26.414,8 | 334,0 | 1,89 |

Concurrencia 4, mediana en ms:

| WMS | Línea base | Optimizado sin caché | Caché caliente |
|---|---:|---:|---:|
| Puntos 256² | 4.922,7 | 201,1 | 3,07 |
| Puntos 1024² | 61.745,5 | 414,6 | 26,94 |
| Líneas 256² | 613,0 | 137,2 | 4,20 |
| Líneas 1024² | 17.625,2 | 424,3 | 17,85 |
| Polígonos 256² | 2.053,3 | 693,0 | 3,82 |
| Polígonos 1024² | 81.164,3 | 843,5 | 22,04 |

La base de puntos dibujaba 1.000 de 1.111 candidatos; la versión optimizada procesa los
1.111. Esa diferencia impide presentarlos como cargas exactamente iguales. Líneas/polígonos
mantienen 1.000 candidatos. La comparación es entre pilotos locales, sin tres repeticiones
independientes ni comparación con un GeoServer configurado de forma equivalente.

Las 144 muestras WMS de la corrida sin caché fueron BYPASS; las 144 de la corrida caliente
fueron HIT después del calentamiento. Las latencias de HIT no representan ventanas nuevas.
El generador valida PNG después de cronometrar; esa validación entra en RPS y puede limitar
throughput a 1024². No extrapolar estos RPS al servidor aislado.

Pico RSS registrado del worker durante cada corrida completa: base 374,2 MiB; optimizado
sin caché 178,6 MiB; con caché caliente 132,9 MiB. Son máximos acumulativos del proceso,
no memoria de una petición ni garantía para otras dimensiones/datos. Parte del menor pico
concurrido procede del límite de dos renders activos, además de los temporales menores.

WFS no se modificó: en concurrencia 1, página de 1.000 con geometría midió 35,9 ms sin
caché frente a 34,3 ms de base; offset 90.000, 102,2 frente a 100,1 ms. No hay mejora WFS
atribuible a estos cambios; su conteo, paginación y serialización siguen como trabajo pendiente.

### Volumen y evolución de memoria

El piloto adicional solicita una ventana completa de 100.000 puntos a 1024² y comprueba
`feature_count=100000`, sin error: 3,49 s en MISS, 1,59 ms en la repetición HIT. Es una
muestra, con puntos simples y solapamiento visual; no demuestra el mismo coste para 100.000
polígonos ni para millones de vértices. No significa que cada punto sea distinguible en PNG.

Después se sirvieron 300 ventanas únicas de 1.000 polígonos a 1024², todas MISS y sin errores,
en cinco bloques de 60 durante 100,2 s:

| Bloque | Mediana ms | RSS MiB al terminar | Payload de caché MiB |
|---|---:|---:|---:|
| 1 | 327,1 | 124,4 | 7,3 |
| 2 | 332,0 | 124,4 | 14,3 |
| 3 | 333,6 | 129,7 | 21,1 |
| 4 | 318,0 | 170,1 | 28,0 |
| 5 | 321,8 | 170,1 | 29,5 |

No apareció degradación de latencia en este tramo. RSS creció durante calentamiento/llenado de
caché y se mantuvo en los dos últimos cortes, dentro de este corpus. Las entradas caducadas
no se sirven, pero pueden seguir ocupando espacio hasta su acceso/evicción; TTL no vacía
automáticamente la memoria. La LRU limita bytes/entradas incluso con claves únicas. Este piloto
breve no diagnostica por sí solo la lentitud de la laptop ni descarta una fuga durante horas.

## Configuración y publicación en producción

Los defaults de esta mejora son una base medible, no una talla universal. El host configura:

```python
from atlas import Atlas, AtlasConfig

config = AtlasConfig(
    database_url=database_url,
    max_render_features=100_000,
    max_render_bytes=64 * 1024 * 1024,
    max_render_concurrency=2,
    wms_cache_max_bytes=32 * 1024 * 1024,  # 0 para frescura sin caché
    wms_cache_max_entries=256,
    wms_cache_ttl=30,
)
geo = Atlas(database_url=database_url, config=config)
# Después de confirmar una actualización en la BD, desde el event loop del host:
geo.invalidate_cache()
```

1. Empezar con un worker y medir la mezcla real; comparar después dos. Cada worker añade pool,
   hasta dos renders y 32 MiB de caché. Con defaults, dos workers admiten hasta veinte conexiones
   del pool, además de otros clientes. Ajustar contra CPU/RAM y capacidad de PostgreSQL.
2. Dimensionar `max_image_size` según el geoportal. Una imagen 4096² a 2× requiere 256 MiB solo
   para el canvas RGBA, antes de temporales, GEOS y compresión. Los presupuestos WKB/features
   no acotan estrictamente RSS. Un lote de driver o una sola geometría enorme puede exceder
   temporalmente el presupuesto restante; no se promete protección dura frente a cualquier dato.
3. El semáforo limita trabajo activo; no fija el tamaño ni tiempo de la cola de clientes.
   Configurar concurrencia, tiempo máximo y desconexiones en el servidor/proxy del host,
   y medir que WFS/health sigan respondiendo durante mapas costosos. No aumentar thread pool
   o workers sin observar latencia, CPU y RAM conjunta. `query_timeout` no limita CPU de Pillow;
   un dibujo nativo iniciado termina aunque el cliente cancele, reteniendo su turno hasta entonces.
4. Conservar GiST/estadísticas actualizadas y verificar planes con BBOX reales. Evitar transformar
   la columna del filtro. Una tabla grande con ventana selectiva no exige cargar la tabla entera.
5. Medir HIT/MISS/BYPASS, latencia por tamaño/capa, errores por presupuesto, conexiones y RSS.
   Para publicación inmediata entre procesos, definir primero cómo notifica el host a cada
   instancia. Si no existe esa coordinación, aceptar TTL explícitamente o usar caché desactivada.
6. Si una vista excede el presupuesto, el cliente recibe 413 explícito. Resolver la escala con
   ventanas/tiles, índices y, tras validación visual, generalización por resolución. Elevar el
   límite solo con pruebas; no ocultar datos ni usar el error como sustituto de optimización.

## Lo aprendido de Mapalab

Se inspeccionó el repositorio público en `develop`; no se midió su despliegue:

- [useWMSLayerFactory.js](https://github.com/iieg-oficial/mapalab/blob/develop/frontend/src/pages/maps/hooks/useWMSLayerFactory.js)
  elige `TileWMS`/`TileLayer` cuando está configurado `tiled`, con `TILED=true`; también admite
  `ImageWMS`. Ventanas repetibles favorecen caché, pero el código del cliente no prueba que
  GeoWebCache esté sirviendo HIT en producción.
- [catalogo_service.py](https://github.com/iieg-oficial/mapalab/blob/develop/backend/app/services/catalogo_service.py)
  conserva catálogos durante 300 s y ofrece invalidación explícita.
- [layerMetadataService.js](https://github.com/iieg-oficial/mapalab/blob/develop/frontend/src/services/layerMetadataService.js)
  reutiliza estadísticas y metadatos de columnas en el frontend.

La lección aplicable es evitar trabajo repetido en cada nivel con límites y frescura conocidos.
La fluidez del geoportal también depende de ventanas, peticiones canceladas y metadatos del
frontend. No se atribuye su ventaja completa a la caché sin capturar su tráfico real.

## Siguiente secuencia

| Paso | Problema | Implementación propuesta | Medida de aceptación |
|---|---|---|---|
| 1. Validación con un geoportal real | El corpus sintético no reproduce la experiencia de navegación | Repetir una secuencia de pan/zoom/capas con Atlas y GeoServer, mismos datos, estilo, resolución, caché fría/caliente y máquina | Cobertura equivalente, p50/p95, errores y RSS por 30–60 min, sin pendiente sostenida de latencia/memoria después del calentamiento |
| 2. Datos grandes selectivos | Falta evidencia con millones de filas y geometrías complejas | Ampliar corpus e inspeccionar `EXPLAIN (ANALYZE, BUFFERS)`; comparar BBOX selectivas y globales | Filas/vértices realmente procesados, tiempo SQL/render y recursos por ventana; no medir solo tamaño de tabla |
| 3. Generalización por resolución, si domina geometría | Ventanas lejanas pueden contener demasiados vértices | Probar clipping/simplificación en PostGIS, con tolerancia ligada a píxel; opt-in solo tras verificar topología/estilos | Misma cobertura, error visual cuantificado, menos WKB/vértices y menor latencia; sin alterar WFS |
| 4. WFS | Conteo exacto, offset alto y serialización siguen costando | Perfilar cada etapa y añadir orden estable antes de mejorar paginación; conservar contratos WFS | Conteos correctos, páginas reproducibles sin omisiones/duplicados, menor CPU/TTFB y RAM con cliente lento |
| 5. Caché de tiles persistente, solo con evidencia | LRU local puede tener pocos aciertos entre BBOX arbitrarios o reinicios | Medir repetición y cardinalidad; primero alinear ventanas WMS del cliente, luego evaluar almacenamiento local acotado | Mejora de hit rate/latencia que justifique invalidación, disco y operación adicionales |

## Evidencia y reproducción

- [Sin caché](../benchmarks/results/2026-10-19-final-uncached.json).
- [Con caché](../benchmarks/results/2026-10-19-final-cached.json).
- [Volumen y ventanas distintas](../benchmarks/results/2026-10-19-final-soak.json).
- [Procedimiento y comandos](../benchmarks/README.md); no ejecutar tests simultáneamente al benchmark.
- Pruebas: 446 tests con PostGIS, ruff, formato y mypy; registro en
  [final-verification.txt](../benchmarks/results/2026-10-19-final-verification.txt). Sin comparación de rendimiento
  contra el despliegue real de Mapalab/GeoServer.
