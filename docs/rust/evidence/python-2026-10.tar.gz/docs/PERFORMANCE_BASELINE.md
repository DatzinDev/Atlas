# Primera línea base de rendimiento

Fecha: 19 de octubre de 2026. Medición del núcleo sin optimizaciones, sobre el commit
`7b53a1cfce370a61e6c5a6271190245e2d78db3c`, con herramientas nuevas en `benchmarks/`.

Documento histórico: consultar [la optimización posterior](PERFORMANCE_OPTIMIZATION.md)
para los límites y tiempos del código modificado. Los artefactos de esta línea base se conservan.

## Alcance

Esta ejecución es un **piloto local de la etapa 1**, para comprobar el banco de pruebas
y atribuir costes. No certifica capacidad de producción ni compara Atlas con GeoServer.
El procedimiento reproducible está en [benchmarks/README.md](../benchmarks/README.md).

Entorno: Linux x86_64, AMD Ryzen 5 7640HS (6 núcleos / 12 hilos), aproximadamente 14.8 GiB
de RAM física, Python 3.13.11. Atlas corre en Uvicorn con un worker, sin access log,
supersampling 2 y límites de la librería por defecto. Aplicación y generador comparten
máquina, sin CPU affinity ni aislamiento de carga ajena; PostgreSQL está limitado a
1 CPU / 512 MiB y usa almacenamiento temporal en RAM.

La imagen de PostgreSQL es `postgis/postgis:16-3.4`, ID local
`sha256:44126d872ac91993766c341e369c539e8196614321765d36a6f1bab0419a5fa5`.
En esa imagen se verificaron PostgreSQL 16.4, PostGIS 3.4.3, GEOS 3.9.0 y PROJ 7.2.1.
La identidad exacta de paquetes y fuentes se conserva en el JSON HTTP.

Corpus: 100,000 puntos; 1,000 líneas de dos vértices; 1,000 polígonos con 129 vértices
cada uno. Todo en EPSG:3857 y con GiST. Es una distribución sintética uniforme cerca
del origen, no una muestra de cartografía real.

## Cómo interpretar los resultados

La carga usa clientes HTTP persistentes y concurrencia cerrada. Se descarta una petición
de calentamiento por caso y concurrencia; se miden 12 peticiones. Los percentiles de
cola tienen poca resolución: con estas 12 muestras, el p95 por rango más próximo es
el máximo. No se informa p99 ni se extrapolan RPS a producción.

La latencia termina al consumir el cuerpo HTTP completo; la validación sucede después.
El throughput incluye validación del cliente. El pico RSS del worker es acumulativo
desde su arranque y no se atribuye como memoria exclusiva de cada escenario.

La ventana WMS de puntos incluye 1,111 candidatos; el límite actual permite dibujar
1,000. Por ello sus tiempos describen **una respuesta truncada**, aunque el PNG sea
válido. Líneas y polígonos tienen 1,000 candidatos. Ninguna mejora de tiempo debe
presentarse como equivalente a un mapa completo sin resolver esta diferencia.

## Resultados HTTP

Se completaron **240 peticiones medidas en 20 combinaciones**, además de 20 de
calentamiento, sin errores HTTP ni de validación estructural. El truncamiento conocido
del mapa de puntos no se cuenta como error HTTP. Los casos medidos acumularon
aproximadamente 18.6 minutos;
WFS solo duró fracciones de segundo por combinación, insuficiente para inferir su
capacidad sostenida. Se conserva la evidencia en
[2026-10-19-http.json](../benchmarks/results/2026-10-19-http.json).

Medianas de tiempo hasta consumir el cuerpo, en milisegundos:

| Escenario | Concurrencia 1 | Concurrencia 4 |
|---|---:|---:|
| WMS puntos 256², mapa truncado | 1,386.9 | 4,922.7 |
| WMS puntos 1024², mapa truncado | 15,507.2 | 61,745.5 |
| WMS líneas 256² | 160.3 | 613.0 |
| WMS líneas 1024² | 4,277.1 | 17,625.2 |
| WMS polígonos 256² | 485.1 | 2,053.3 |
| WMS polígonos 1024² | 26,414.8 | 81,164.3 |
| WFS 10 features | 5.8 | 8.7 |
| WFS 1,000 features | 34.3 | 120.2 |
| WFS 1,000 features, offset 90,000 | 100.1 | 289.4 |
| WFS 1,000 features, sin geometría | 23.6 | 73.7 |

En puntos 1024² el throughput pasó de 0.0628 a 0.0623 respuestas/s al aumentar
concurrencia: no mejoró. En polígonos 1024² sí aumentó de 0.0374 a 0.0491 respuestas/s,
pero la mediana de latencia se triplicó; los cuatro hilos no aportaron un escalado
proporcional. Son resultados de un worker con hilos, no una prueba de varios procesos.

El mayor pico RSS observado por el worker fue **374.2 MiB**, acumulativo durante toda
la batería. No incluye PostgreSQL ni el cliente de carga y no demuestra ausencia de
fugas. Tampoco permite extrapolar directamente a imágenes de 4096² o 40 renders.

El offset profundo elevó la mediana WFS de 34.3 a 100.1 ms. Omitir geometría la redujo
a 23.6 ms. Ambos resultados justifican medir esos caminos con mayor duración antes
de cambiar contratos de paginación o serialización.

## Atribución por etapas y perfil de Pillow

Se ejecutaron tres repeticiones de cada combinación de geometría y tamaño, en procesos
nuevos, usando `run_in_threadpool` como GetMap. Los 18 registros están en
[2026-10-19-stages.jsonl](../benchmarks/results/2026-10-19-stages.jsonl).
Son primeros renders de procesos nuevos, con la base caliente, no un worker HTTP
reutilizado. El calentamiento y el historial de asignaciones son distintos: estos
tiempos no reemplazan las medianas HTTP anteriores.

Medianas de las tres repeticiones a 1024², en milisegundos:

| Geometría | Conteo diagnóstico | Consulta + transferencia WKB | Decodificación WKB | Render completo |
|---|---:|---:|---:|---:|
| Puntos | 1.07 | 10.98 | 4.60 | 24,192.17 |
| Líneas | 1.18 | 1.58 | 4.63 | 19,033.80 |
| Polígonos | 1.04 | 11.83 | 7.88 | 25,253.89 |

El conteo es una comprobación adicional para detectar truncamiento; **GetMap no lo
ejecuta actualmente**. Aun incluyéndolo, el render representa más del 99.9 % del tiempo
de esos cuatro bloques en las muestras de 1024². Esto demuestra el cuello en este
corpus; no excluye problemas SQL con otros datos, vistas, filtros o CRS.

Los planes guardados muestran que el conteo de puntos usa `points_geom_idx`, mientras
la selección limitada puede elegir un scan secuencial paralelo. En un plan capturado,
la selección tardó 9.56 ms y el conteo 0.33 ms. La presencia de un índice no obliga al
planificador a usarlo; forzarlo no es la primera intervención frente a segundos de render.

Se capturaron dos ejecuciones adicionales con `cProfile`, activado dentro del hilo de
render. No se mezclaron con las muestras anteriores. Los detalles están en
[2026-10-19-cprofile-summary.json](../benchmarks/results/2026-10-19-cprofile-summary.json),
[perfil de puntos](../benchmarks/results/2026-10-19-profile-points.json) y
[perfil de polígonos](../benchmarks/results/2026-10-19-profile-polygons.json).

| Operaciones nativas | Puntos 1024² | Polígonos 1024² |
|---|---:|---:|
| Composición alfa | 16.68 s | 10.69 s |
| Relleno de imágenes | 1.71 s | 7.36 s |
| Copiado `paste` | 2.72 s | 2.95 s |
| Proporción del tiempo perfilado entre las tres | 89.46 % | 82.85 % |

En ambos casos hubo 2,000 llamadas nativas de composición alfa para 1,000 geometrías.
La evidencia coincide con las superficies completas creadas por `_draw`; no señala
conversión de coordenadas ni codificación PNG como primer objetivo.

## Decisiones para la siguiente etapa

1. **Primer cambio: reducir las superficies de Pillow por geometría (F1).** Limitar
   overlays, máscaras y rellenos al rectángulo de píxeles afectado, con margen para
   bordes y símbolos. Conservar orden de dibujo, opacidad, huecos, clipping y
   supersampling 2; mantener la interfaz `MapRenderer`. La ganancia de ese cambio aún
   no está medida: aquí se ha comprobado el coste actual.
2. **Validar antes de comparar velocidad.** Reutilizar los tests de píxeles existentes
   y añadir bordes del lienzo, geometrías parcialmente fuera de ventana y trazos anchos.
   Repetir la batería HTTP con mismos datos, runtime, estilos y límites; comparar
   imágenes decodificadas, latencia, CPU y memoria.
3. **Tratar el límite WMS como corrección separada (F2).** El benchmark ya confirma
   1,111 candidatos frente a 1,000 geometrías seleccionadas. No aumentar el límite
   dentro del cambio de renderer ni llamar completo al mapa truncado.
4. **Después, medir WFS con más duración.** Profundizar en el offset y la proyección
   de geometría; conservar el conteo exacto y `startIndex` durante ese diagnóstico.

No se cambiarán workers, geometrías, supersampling y renderer simultáneamente para
atribuir una mejora. El experimento actual no justifica cambiar lenguaje, añadir una
caché distribuida ni sustituir el motor antes de reducir el trabajo redundante.

## Verificación y estado del workspace

- Suite completa contra la base temporal: **426 passed**, sin skips, en 6.61 s.
- Ruff lint y formato de las herramientas y sus tests: correctos.
- Los cinco tests del runner comprueban validación y contabilización de fallos.
- Se conservaron paquetes resueltos en
  [2026-10-19-requirements.txt](../benchmarks/results/2026-10-19-requirements.txt).
- No se modificaron `src/`, dependencias del núcleo ni el Compose de desarrollo.

Antes de dimensionar producción faltan corpus reales, carga de duración sostenida y
repetida, clientes lentos/cancelación, exportaciones concurrentes, múltiples workers,
cachés, lag del event loop y una comparación con GeoServer bajo calidad y cobertura
equivalentes. Las comprobaciones de cancelación existentes pasaron en la suite; aún
no se midió su comportamiento bajo carga sostenida.
